<?php
use \Firebase\JWT\JWT;

/**
 * SaleForm Registration
 * @author  <your name here>
 */
class CompartilhamentoForm extends TPage
{
    protected $form; // form
    public $product_list;
    
    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct()
    {
        parent::__construct();
        $this->setTargetContainer('adianti_right_panel');
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Compartilhamento');
        $this->form->setFormTitle('Compartilhamento');
        $this->form->setProperty('style', 'margin:0;border:0');
        $this->form->setClientValidation(true);
        
        // master fields
        $questionario_id = new TEntry('questionario_id');
        $titulo          = new TEntry('titulo');
        
        // detail fields
        $detail_uniqid     = new THidden('uniqid');
        $detail_id         = new THidden('id');
        $detail_user_email = new TEntry('user_email');
        
        // adjust field properties
        $questionario_id->setEditable(false);
        $titulo->setEditable(false);
        $titulo->setSize('100%');
        $detail_user_email->addValidation('Email', new TEmailValidator); // email field
        
        
        // add master form fields
        $this->form->addFields( [new TLabel('ID')], [$questionario_id] );
        $this->form->addFields( [new TLabel('Questionário')], [$titulo] );
        
        //details
        $this->form->addContent( ['<hr>'] );
        $this->form->addFields( [$detail_uniqid], [$detail_id] );
        $this->form->addFields( [ new TLabel('Email', '#FF0000') ], [$detail_user_email] );
        
        $add_product = TButton::create('add_product', [$this, 'onProductAdd'], 'Register', 'fa:plus-circle green');
        $add_product->getAction()->setParameter('static','1');
        $this->form->addFields( [], [$add_product] );
        
        $this->product_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->product_list->setHeight(150);
        $this->product_list->makeScrollable();
        $this->product_list->setId('products_list');
        $this->product_list->generateHiddenFields();
        $this->product_list->style = "min-width: 700px; width:100%;margin-bottom: 10px";
        
        $col_uniqid= new TDataGridColumn( 'uniqid', 'Uniqid', 'center', '10%');
        $col_id    = new TDataGridColumn( 'id', 'ID', 'center', '10%');
        $col_email = new TDataGridColumn( 'user_email', 'Email', 'left', '90%');
        
        $this->product_list->addColumn( $col_uniqid );
        $this->product_list->addColumn( $col_id );
        $this->product_list->addColumn( $col_email );
        
        $col_uniqid->setVisibility(false);
        $col_id->setVisibility(false);
        
        // creates two datagrid actions
        $action1 = new TDataGridAction([$this, 'onEditItemProduto'] );
        $action1->setFields( ['uniqid', '*'] );
        
        $action2 = new TDataGridAction([$this, 'onDeleteItem']);
        $action2->setField('uniqid');
        
        // add the actions to the datagrid
        $this->product_list->addAction($action1, _t('Edit'), 'far:edit blue');
        $this->product_list->addAction($action2, _t('Delete'), 'far:trash-alt red');
        
        $this->product_list->createModel();
        
        $panel = new TPanelGroup;
        $panel->add($this->product_list);
        $panel->getBody()->style = 'overflow-x:auto';
        $this->form->addContent( [$panel] );
        
        $this->form->addHeaderActionLink( _t('Close'),  new TAction(['QuestionarioList', 'onReload'] ), 'fa:times red');
        $this->form->addAction( _t('Save'),  new TAction([$this, 'onSave'], ['static'=>'1']), 'fa:save green');
        $this->form->addAction( _t('Clear'), new TAction([$this, 'onReload']), 'fa:eraser red');
        $this->form->addAction( _t('Email'), new TAction([$this, 'onSendEmail']), 'fa:share green');
        
        
        // create the page container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->add($this->form);
        parent::add($container);
    }
    
    /**
     * Clear form
     * @param $param URL parameters
     */
    function onClear($param)
    {
        $this->form->clear();
        $object = new stdClass();
        $object->questionario_id = TSession::getValue('questionario_id');
        $this->form->setData($object);        
    }
    
    /**
     * Add a product into item list
     * @param $param URL parameters
     */
    public function onProductAdd( $param )
    {
        try
        {
            $this->form->validate();
            $data = $this->form->getData();
            
            $uniqid = !empty($data->uniqid) ? $data->uniqid : uniqid();
            
            $grid_data = [ 'uniqid'     => $uniqid,
                           'id'         => $data->id,
                           'user_email' => $data->user_email ];
            
            // insert row dynamically
            $row = $this->product_list->addItem( (object) $grid_data );
            $row->id = $uniqid;

            TDataGrid::replaceRowById('products_list', $uniqid, $row);
            
            // clear product form fields after add
            $data->uniqid = '';
            $data->id = '';
            $data->user_email = '';
            
            // send data, do not fire change/exit events
            TForm::sendData( 'form_Compartilhamento', $data, false, false );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());
            new TMessage('error', $e->getMessage());
        }
    }
    
    /**
     * Edit a product from item list
     * @param $param URL parameters
     */
    public static function onEditItemProduto( $param )
    {
        $data = new stdClass;
        $data->uniqid     = $param['uniqid'];
        $data->id         = $param['id'];
        $data->user_email = $param['user_email'];
        
        // send data, do not fire change/exit events
        TForm::sendData( 'form_Compartilhamento', $data, false, false );
    }
    
    /**
     * Delete a product from item list
     * @param $param URL parameters
     */
    public static function onDeleteItem( $param )
    {
        $data = new stdClass;
        $data->uniqid = '';
        $data->id = '';
        $data->user_email = '';

        // send data, do not fire change/exit events
        TForm::sendData( 'form_Compartilhamento', $data, false, false );

        // remove row
        TDataGrid::removeRowById('products_list', $param['uniqid']);
    }
    
    /**
     * Edit Sale
     */
    public function onEdit($param)
    {
        try
        {
            TTransaction::open('questionario');
            
            if (isset($param['key']))
            {
                $key = $param['key'];
                
                $object = new Alternativas($key);
                $alternativa_items = Alternativas::where('pergunta_id', '=', $object->id)->load();
                
                foreach( $alternativa_items as $item )
                {
                    $item->uniqid = uniqid();
                    $row = $this->product_list->addItem( $item );
                    $row->id = $item->uniqid;
                }
                $this->form->setData($object);
                TTransaction::close();
            }
            else
            {
                $this->form->clear();
                $object = new stdClass();
                $object->questionario_id = TSession::getValue('questionario_id');
                $this->form->setData($object);
            }
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }
    
    /**
     * Save the sale and the sale items
     */
    public function onSave($param)
    {
        try
        {
            TTransaction::open('questionario');
            
            $data = $this->form->getData();
            $this->form->validate();

            Compartilhamentos::where('questionario_id', '=', $param['questionario_id'])->delete();

            if( !empty($param['products_list_id'] ))
            {
                foreach( $param['products_list_id'] as $key => $item_id )
                {
                    $item = new Compartilhamentos;
                    $item->questionario_id = $param['questionario_id'];
                    $item->user_email      = $param['products_list_user_email'][$key];                    
                    $item->store();
                    TForm::sendData('form_Compartilhamento', (object) ['id' => $item->id]);
                }
            }            
            TTransaction::close(); // close the transaction
            
            //User
            TTransaction::open('permission');
            //TTransaction::setLogger(new TLoggerSTD); // standard output
            if( !empty($param['products_list_id'] ))
            {
                foreach( $param['products_list_id'] as $key => $item_id )
                {
                    $email = $param['products_list_user_email'][$key];

                    //users
                    $objects = SystemUser::where('email', '=', $email)->load();

                    if( !$objects ){
                        $user = new SystemUser;
                        $user->name  = $param['products_list_user_email'][$key];
                        $user->login = $param['products_list_user_email'][$key];
                        $user->email = $param['products_list_user_email'][$key];
                        $user->active= 'Y';
                        $user->store();
                        //Group
                        $group = new SystemUserGroup;
                        $group->system_user_id  = $user->id;
                        $group->system_group_id = 3; //Group Aluno
                        $group->store();
                    }
                }
            }            
            TTransaction::close(); // close the transaction           
            
            new TMessage('info', TAdiantiCoreTranslator::translate('Record saved'));
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback();
        }
    }
    
    /**
     * Closes window
     */
    public static function onClose()
    {
        TScript::create("Template.closeRightPanel()");
    }
    
    /**
     * on reload comment
     */
    public function onReload($param = NULL)
    {
        try
        {
            TTransaction::open('questionario');
            $repository = new TRepository('Compartilhamentos');
            $limit = 10;

            // creates a criteria
            $criteria = new TCriteria;
            $criteria->add(new TFilter('questionario_id', '=', $param['questionario_id']));            
            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $limit);
            TSession::setValue('questionario_id', $param['id']);
            
            // load the objects according to criteria
            $objects = $repository->load($criteria);
            
            $this->product_list->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {
                    // add the object inside the datagrid
                    $object->uniqid = uniqid();
                    $row = $this->product_list->addItem($object);
                    $row->id = $object->uniqid;
                }
            }
            
            // reset the criteria for record count
            $criteria->resetProperties();
   
            $questionario = new Questionarios($param['questionario_id']);
            $questionario->questionario_id = $questionario->id;
            unset($questionario->id);
            $this->form->setData($questionario);
            
            $btnName = strtolower('btn_'._t('Clear'));
            $btn = $this->form->getField($btnName);
            $btn->setAction(new TAction([$this, 'onReload'], $param ), _t('Clear'));
            
            // close the transaction
            TTransaction::close();

        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }    
    /**
     * Send Email
     */
    public function onSendEmail($param)
    {
        try
        {
            TTransaction::open('questionario');
            $ini = AdiantiApplicationConfig::get();
            $data = $this->form->getData();
            $this->form->validate();

            $id = $param['questionario_id'];
            if( $id == null )
                throw new Exception(_t('Permission denied'));
            
            $questionario = new Questionarios($id);
                                //where('id', '=', $id)->load();
                    
            $compartilhamentos = Compartilhamentos::
                                where('questionario_id', '=', $id)->load();

            if( $compartilhamentos ){
                //User
                TTransaction::open('permission');
                foreach ($compartilhamentos as $row) {
                    //users
                    $user = SystemUser::newFromEmail($row->user_email);
                    if( $user ){
                        $key = APPLICATION_NAME . $ini['general']['seed'];

                        $token = array(
                            "user" => $user->login,
                            "user_id" => $user->id,
                            "expires" => strtotime("+ 3 hours"),
                            "questionario_id" => $id
                        );

                        $jwt = JWT::encode($token, $key);

                        $referer = $_SERVER['HTTP_REFERER'];
                        $url = substr($referer, 0, strpos($referer, 'index.php'));
                        $urlResponde = $url . 'index.php?class=ResponderFormView&method=onLoad&jwt='.$jwt;
                        $url .= 'index.php?class=SystemPasswordResetForm&method=onLoad&jwt='.$jwt;
                        
                        $replaces = [];
                        $replaces['responsavel'] = TSession::getValue('username');
                        $replaces['name'] = $user->name;
                        $replaces['titulo'] = $questionario->titulo;
                        $replaces['periodo'] = TDate::date2br($questionario->data_fim).' as '.
                                               $questionario->hora_fim;
                        $replaces['link'] = $url;
                        $replaces['linkResponder'] = $urlResponde;
                        
                        $html = new THtmlRenderer('app/resources/questionario_responder.html');
                        $html->enableSection('main', $replaces);
                        
                        MailService::send( [$user->email], 'Responder ao questionário', $html->getContents(), 'html' );
                        
                    }                    
                }
                TTransaction::close(); // close the transaction
            }
            TTransaction::close(); // close the transaction
            
            new TMessage('info', _t('Message sent successfully'));            
            $this->onReload($param);
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback();
        }
    }    
}
