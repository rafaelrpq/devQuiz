<?php

/**
 * MultiStepMultiForm2View
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class MultiStepMultiForm2View extends TPage {

    private $form; // form
    private $formFields;

    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct() {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder('form_account');
        $this->form->setFormTitle('Responda ao Questionário');
        $this->form->setColumnClasses(2, ['col-sm-3', 'col-sm-9']);

        // create the form fields
        $questionario       = new TEntry('questionario');
        $perguntas = new THidden('perguntas');
        $questionario->setEditable(FALSE);

        // add the fields
        $this->form->addFields(['Questionário'], [$questionario]);
        $this->form->addFields([], [$perguntas] );
        // add a form action
        $this->form->addAction('Back', new TAction(array($this, 'onBackForm')), 'fa:chevron-circle-left orange');
        $this->form->addAction('Confirm', new TAction(array($this, 'onConfirm')), 'far:check-circle green');

        $this->onLoadFromForm1();

        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', 'MultiStepMultiFormView'));
        $vbox->add($this->form);

        // add the form to the page
        parent::add($vbox);
    }

    /**
     * load the previous data
     */
    public function onLoadFromForm1() {
        $data = TSession::getValue('form_step1_data');
        
        $data->perguntas = trim($data->perguntas);
        $i   = strpos($data->perguntas, "$");
        $f   = strpos($data->perguntas, "=");
        $var = trim(substr($data->perguntas, $i+1, $f-1));
        eval($data->perguntas);
        $perguntas = $$var;
        $this->form->setData($data);
        
        // Exemplo de uso:
        //$formFields = $this->formFields;
        $i=1;
        foreach ($perguntas as $indice => $pergunta) {
            //echo "Pergunta " . ($indice + 1) . ": " . $pergunta['pergunta'] . "\n";
            
            $perg  = array_keys($pergunta)[0] ;
            $alter = array_keys($pergunta)[1] ;
            $resp  = array_keys($pergunta)[2] ;
            
            $labelPergunta = "Pergunta " . ($i) . ": " . $pergunta[ $perg ];
            $checkLabel = new TCheckButton("check$i");
            $checkLabel->setIndexValue('on');
            
            $radio = new TRadioGroup("radio$i");
            $radio->addValidation( "'{$pergunta[ $perg ]}'", new TRequiredValidator);
            
            $alternativaCorreta = strtoupper(substr( $i.$pergunta[$resp], 0, 2 ));

            $items = array();
            foreach ($pergunta[ $alter ] as $alternativa => $texto) {
                $alternativa = preg_replace('/[^A-Za-z]/', '', strtoupper($alternativa));
                $opcao = $alternativa ? $alternativa : preg_replace('/[^A-Za-z]/', '', strtoupper($i.substr($texto,0,1)));
                $items[$opcao] = ( $alternativa ? $alternativa . ") " : "" ) . $texto;
            }
            //echo "Alternativa correta: " . $pergunta[$resposta] . "\n\n";
            $labelResposta = "Alternativa correta: $i ($pergunta[$resp])";
            $radio->addItems($items);

            $row = $this->form->addFields([$checkLabel], [new TLabel($labelPergunta)],[$radio]);
            $row->layout = ['col-lg-1','col-sm-5','col-sm-5'];
            //$row = $this->form->addFields([$radio]);
            $row = $this->form->addFields([],[],[new TLabel($labelResposta)]);
            $row->layout = ['col-lg-1','col-sm-5','col-sm-5'];
            $i++;
        }
    }

    /**
     * Load the previous form
     */
    public function onBackForm() {
        // Load another page
        AdiantiCoreApplication::loadPage('MultiStepMultiFormView', 'onLoadFromSession');
    }

    /**
     * confirmation screen
     */
    public function onConfirm($param) {
        try {
            //$this->form->validate();
            $data = $this->form->getData();
            $this->validaPerguntas($data);
        } catch (Exception $e) {
            new TMessage('error', $e->getMessage());
        }
    }
    
    /**
     * Valida Perguntas
     * @param object $data
     */
    public function validaPerguntas($data){
        $data->perguntas = trim($data->perguntas);
        $i   = strpos($data->perguntas, "$");
        $f   = strpos($data->perguntas, "=");
        $var = trim(substr($data->perguntas, $i+1, $f-1));
        eval($data->perguntas);
        $perguntas = $$var;

        try
        {
            // open a transaction with database 'permission'
            TTransaction::open('questionario');

            // Exemplo de uso:
            $msgRetorno = '';
            $i=1;
            foreach ($perguntas as $indice => $pergunta) {
                //echo "Pergunta " . ($indice + 1) . ": " . $pergunta['pergunta'] . "\n";
                if( $i == 1){
                    $questionario = new Questionarios;
                    $questionario->titulo = $data->questionario;
                    $questionario->descricao = $data->questionario;
                    $questionario->user_id = TSession::getValue('userid');
                    $questionario->store();
                }

                $perg  = array_keys($pergunta)[0] ;
                $alter = array_keys($pergunta)[1] ;
                $resp  = array_keys($pergunta)[2] ;

                $labelPergunta = "Pergunta " . ($i) . ": " . $pergunta[ $perg ];
                //$radio = new TRadioGroup("radio$i");
                $radio = $data->{"radio$i"};
                $check = $data->{"check$i"};

                if( $check == 'on' ){
                    //Add pergunta
                    $texto_pergunta = trim($pergunta[ $perg ]);
                    $alternativaCorreta = strtoupper(substr( $i.$pergunta[$resp], 0, 2 ));
                    $perg = new Perguntas;
                    $perg->questionario_id  = $questionario->id;
                    $perg->pergunta_texto   = $texto_pergunta;
                    $perg->tipo_alternativa = 'Opcao';
                    $perg->resposta_correta = $alternativaCorreta; 
                    $perg->store();                    

                    // add the combo items
                    $items = array();
                    foreach ($pergunta[ $alter ] as $alternativa => $texto) {
                        $alternativa = preg_replace('/[^A-Za-z]/', '', strtoupper($alternativa));
                        $opcao = $alternativa ? $alternativa : preg_replace('/[^A-Za-z]/', '', strtoupper($i.substr($texto,0,1)));
                        //echo ( $alternativa ? $alternativa . ") " : "" ) . $texto . "\n";
                        $alternativa_texto = ( $alternativa ? $alternativa . ") " : "" ) . $texto;
                        $items[$opcao] = $alternativa_texto;
                        
                        //Add Alternativas
                        $alt = new Alternativas;
                        $alt->questionario_id = $questionario->id;
                        $alt->pergunta_id = $perg->id;
                        $alt->alternativa_texto = $alternativa_texto;
                        $alt->alternativa_correta = ($alternativaCorreta == $i.$opcao ? 'S':'N');
                        $alt->store();
                    }
                    $msgRetorno = 'inclui';
                }
                $i++;
            }

            // close the transaction
            TTransaction::close();
            
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
            
        if( !empty($msgRetorno) )
            new TMessage('info', 'Questionário incluso.');
        else
            new TMessage('warning', 'Marque a(s) pergunta(s) para inclusão.');
            
        
    }
    
}
