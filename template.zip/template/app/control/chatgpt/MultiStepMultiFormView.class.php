<?php
/**
 * MultiStepMultiFormView
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class MultiStepMultiFormView extends TPage
{
    protected $form; // form
    
    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct()
    {
        parent::__construct();
        //Js
        TScript::importFromFile('app/lib/include/chatGPT/app.js');
    
        // creates the form
        $this->form = new BootstrapFormBuilder('form_account');
        $this->form->setFormTitle('Quiz com chatGPT');
        $this->form->setColumnClasses(2, ['col-sm-3', 'col-sm-9']);
        
        // create the form fields
        $questionario       = new TEntry('questionario');
        $questionario->setValue('Questionário');
        
        $qtdPerguntas = new TEntry('qtdPerguntas');
        $qtdPerguntas->setMask('99');
        $qtdPerguntas->setValue('2');
        
        $qtdAlternativas = new TEntry('qtdAlternativas');
        $qtdAlternativas->setMask('99');
        $qtdAlternativas->setValue('2');
        
        $tema= new TText('tema');
        $tema->setValue('inspeção de software');
//        $tema->setValue('elabore 2 perguntas, contendo 2 alternativas,  e mostre  a alternativa correta
//sobre inspeção de software, retorne um array com perguntas, alternativas e resposta correta  para php ');
        
        $perguntas    = new TText('perguntas');
        $perguntas->setSize('100%',300);
        
        

        
        /**
         * 25/05 - 
         * 1) elaborar peruntas com código fontes
         *    Ex: mostre código php como erros comuns que podem ser detectados 
         *        com análise estática de código
         * 2) elaborar banco de dados de perguntas
         * 3) ver instegração com https://kahoot.com/
         * 
         * 15/06 -
         * 1) configurações do jogo
         *  1.1) OK - Agendar jogo? 
         *  1.3) OK - Cadastrar email...enviar email com link para o jogo tipo kahoot
         *  1.4) Ranking por jogo
         *  1.5) ranking por disciplina
         *  1.6) Ver BARD para ler aquivo PDF e gerar perguntas
         * 
         * 22/06
         *  1.2) OK Jogar agora...criar link para jogar questionário especifico
         *  1) OK informar dt inicio e fim
         *  2) questionario atual como remoto
         *  3) questionario em sala de aula (prof. projeta, aluno responde )
         */

        $this->form->addFields(['Questionário'], [$questionario] );
        $this->form->addFields(['Quantidade de Perguntas'], [$qtdPerguntas] );
        $this->form->addFields(['Quantidade de Alternativas'], [$qtdAlternativas] );
        $this->form->addFields(['Tema'], [$tema] );
        $this->form->addFields(['Retorno chatGPT'], [$perguntas] );
    
        // validations
        $questionario->addValidation('Questionário', new TRequiredValidator);
        $qtdPerguntas->addValidation('Quantidade de Perguntas', new TRequiredValidator);
        $qtdAlternativas->addValidation('Quantidade de Alternativas', new TRequiredValidator);
        $tema->addValidation('Tema', new TRequiredValidator);

        // add a form action
        $this->form->addAction('Elabore Perguntas', new TAction(array($this, 'onPergunta')), 'fa:question-circle red');
        $this->form->addAction('Next', new TAction(array($this, 'onNextForm')), 'fa:chevron-circle-right green');

        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $vbox->add($this->form);
        
        // add the form to the page
        parent::add($vbox);
    }
    
    /**
     * Load form from session
     */
    public function onLoadFromSession()
    {
        $data = TSession::getValue('form_step1_data');
        $this->form->setData($data);
    }
    
    /**
     * onNextForm
     */
    public function onPergunta()
    {
        try
        {
            $this->form->validate();
            $data = $this->form->getData();
            
            $elaborar  = 'elabore '.$data->qtdPerguntas.' perguntas, ';
            $elaborar .= 'contendo '.$data->qtdAlternativas.' alternativas,  e mostre  a alternativa correta ';
            $elaborar .= 'sobre '.$data->tema.', ';
            $elaborar .= ' '.$data->tema.', ';
            $elaborar .= 'retorne um array com perguntas, alternativas e resposta correta  para php';
            
            TScript::create("sendQuestion('{$elaborar}')");
            //TScript::create("sendQuestion('{$data->tema}')");
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }
    /**
     * onNextForm
     */
    public function onNextForm($param)
    {
        try
        {
            $this->form->validate();
            $data = $this->form->getData();
            
            if ( empty($data->perguntas) )
            {
                throw new Exception('Clique em Elabore Perguntas ');
            }
            // store data in the session
            TSession::setValue('form_step1_data', $data);
            
            // Load another page
            //AdiantiCoreApplication::loadPage('MultiStepMultiForm2View', 'onLoadFromForm1', (array) $data);
            AdiantiCoreApplication::loadPage('MultiStepMultiForm2View');
            
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
        }
    }
    
}
