<?php
/**
 * SystemUserForm
 *
 * @version    1.0
 * @package    control
 * @subpackage admin
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class PerguntaForm extends TPage
{
    protected $form; // form
    protected $program_list;
    private static $db = 'questionario';
    private static $aRecord = 'Perguntas';
    
    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct()
    {
        parent::__construct();
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Pergunta');
        $this->form->setFormTitle( 'Pergunta' );
        
        // create the form fields
        $id             = new TEntry('id');
        $questionario_id  = new TEntry('questionario_id');
        $pergunta_texto = new TEntry('pergunta_texto');
        $tipo_alternativa  = new TEntry('tipo_alternativa');
        
        $btn = $this->form->addAction( _t('Save'), new TAction(array($this, 'onSave')), 'far:save');
        $btn->class = 'btn btn-sm btn-primary';
        $this->form->addActionLink( _t('Clear'), new TAction(array($this, 'onEdit')), 'fa:eraser red');
        $back = new TAction(array($this,'onReloadBack'));
        $this->form->addActionLink( _t('Back'), $back, 'far:arrow-alt-circle-left blue');
        
        // define the sizes
        $id->setSize('50%');
        $pergunta_texto->setSize('100%');
        $tipo_alternativa->setSize('100%');
        
        // outros
        $id->setEditable(false);
        
        // validations
        $pergunta_texto->addValidation('Pergunta', new TRequiredValidator);
        $tipo_alternativa->addValidation('Tipo Resposta', new TRequiredValidator);
        
        $this->form->addFields( [new TLabel('ID')], [$questionario_id] );
        $this->form->addFields( [new TLabel('ID')], [$id] );
        $this->form->addFields( [new TLabel('Pergunta')], [$pergunta_texto] );
        $this->form->addFields( [new TLabel('Tipo Resposta')], [$tipo_alternativa] );        
        
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->add($this->form);

        // add the container to the page
        parent::add($container);
    }

    /**
     * Save user data
     */
    public function onSave($param)
    {
        try
        {
            // open a transaction with database 'permission'
            TTransaction::open(self::$db);
                        
            $data = $this->form->getData();
            $this->form->setData($data);
            
            $object = new Perguntas;
            $object->fromArray( (array) $data );
            
            $object->store();

            $data = new stdClass;
            $data->id = $object->id;
            TForm::sendData('form_Pergunta', $data);
            
            // close the transaction
            TTransaction::close();
            
            // shows the success message
            new TMessage('info', TAdiantiCoreTranslator::translate('Record saved'));
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }
    
    /**
     * method onEdit()
     * Executed whenever the user clicks at the edit button da datagrid
     */
    function onEdit($param)
    {
        try
        {
            if (isset($param['key']))
            {
                // get the parameter $key
                $key=$param['key'];
                
                // open a transaction with database 'permission'
                TTransaction::open(self::$db);
                
                // instantiates object System_user
                $object = new Perguntas($key);

                // fill the form with the active record data
                $this->form->setData($object);
                
                // close the transaction
                TTransaction::close();
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }
    /**
     * method onEdit()
     * Executed whenever the user clicks at the edit button da datagrid
     */
    function onReloadBack($param)
    {
        try
        {
            $data = $this->form->getData();
            $this->form->setData($data);
            var_dump($data);
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }
}
