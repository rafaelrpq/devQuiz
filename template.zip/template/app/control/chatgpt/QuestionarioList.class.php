<?php
/**
 * SystemUserList
 *
 * @version    1.0
 * @package    control
 * @subpackage admin
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class QuestionarioList extends TStandardList
{
    protected $form;     // registration form
    protected $datagrid; // listing
    protected $pageNavigation;
    protected $formgrid;
    protected $deleteButton;
    protected $transformCallback;
    
    /**
     * Page constructor
     */
    public function __construct()
    {
        parent::__construct();
        
        parent::setDatabase('questionario');            // defines the database
        parent::setActiveRecord('Questionarios');   // defines the active record
        parent::setDefaultOrder('id', 'asc');         // defines the default order
        parent::addFilterField('id', '=', 'id'); // filterField, operator, formField
        parent::addFilterField('user_id', '=', TSession::getValue('userid') ); // filterField, operator, formField
        parent::addFilterField('titulo', 'like', 'titulo'); // filterField, operator, formField

        //Filtra por usuário logado
        $criteria = new TCriteria;
        $criteria->add(new TFilter('user_id', '=', TSession::getValue('userid')));            
        $this->setCriteria($criteria);

        // creates the form
        $this->form = new BootstrapFormBuilder('form_search_SystemUser');
        $this->form->setFormTitle('Questionários');       

        // create the form fields
        $id = new TEntry('id');
        $titulo = new TEntry('titulo');
        $descricao = new TEntry('descricao');
        
        // add the fields
        $this->form->addFields( [new TLabel('Id')], [$id] );
        $this->form->addFields( [new TLabel('Título')], [$titulo] );
        $this->form->addFields( [new TLabel('Descrição')], [$descricao] );
        
        $id->setSize('30%');
        $titulo->setSize('70%');
        $descricao->setSize('70%');
        
        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue('SystemUser_filter_data') );
        
        // add the search form actions
        $btn = $this->form->addAction(_t('Find'), new TAction(array($this, 'onSearch')), 'fa:search');
        $btn->class = 'btn btn-sm btn-primary';
        $this->form->addAction(_t('New'),  new TAction(array('QuestionarioForm', 'onEdit')), 'fa:plus green');
        
        // creates a DataGrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        //$this->datagrid->datatable = 'true';
        $this->datagrid->style = 'width: 100%';
        //$this->datagrid->setHeight(420);
        $this->datagrid->datatable ='true';

        
        $button = new TActionLink('', new TAction([$this, 'onReload']), 'green', null, null, 'fa:plus-circle');
        $button->class = 'btn btn-default inline-button';
        $button->title = _t('New');
        
        // creates the datagrid columns
        $column_id = new TDataGridColumn('id', 'Id', 'center', 50);
        $column_titulo = new TDataGridColumn('titulo', 'Título', 'left');
        $column_descricao = new TDataGridColumn('descricao', 'Descrição', 'left');
        $column_criacao = new TDataGridColumn('data_criacao', 'Data Criação', 'left');
        $column_criacao->setTransformer(array($this, 'formatDate'));
        
        $column_titulo->enableAutoHide(500);
        $column_descricao->enableAutoHide(500);
        // add the columns to the DataGrid
        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_titulo);
        $this->datagrid->addColumn($column_descricao);
        $this->datagrid->addColumn($column_criacao);

        // creates two datagrid actions
        $action3 = new TDataGridAction(['PerguntaList', 'onReload'], ['id' => '{id}' ] );
        $action4 = new TDataGridAction(['CompartilhamentoForm', 'onReload'], ['questionario_id' => '{id}' ] );
        $action5 = new TDataGridAction([$this, 'onClone'], ['id' => '{id}' ] );
        $action6 = new TDataGridAction([$this, 'onAtribuir'], ['id' => '{id}' ] );

        $action3->setLabel('Perguntas');
        $action3->setImage('far:question-circle green');

        $action4->setLabel('Compartilhar');
        $action4->setImage('fa:fa fa-share-alt');

        $action5->setLabel(_t('Clone'));
        $action5->setImage('far:clone green');
        
        $action5->setLabel(_t('Clone'));
        $action5->setImage('far:clone green');

        $action6->setLabel('Atribuir');
        $action6->setImage('fa:fa fa-calendar-plus blue');

        $action_group = new TDataGridActionGroup('Actions ', 'fa:th');
        
        //$action_group->addHeader('Available Options');
//        $action_group->addAction($action1);
//        $action_group->addAction($action2);
//        $action_group->addSeparator();
        //$action_group->addHeader('Another Options');
        $action_group->addAction($action3);
        $action_group->addAction($action4);
        $action_group->addAction($action5);
        $action_group->addSeparator();
        $action_group->addAction($action6);
        
        // add the actions to the datagrid
        $this->datagrid->addActionGroup($action_group);
        
         // create EDIT action
        $action_edit = new TDataGridAction(array('QuestionarioForm', 'onEdit'));
        $action_edit->setButtonClass('btn btn-default');
        $action_edit->setLabel(_t('Edit'));
        $action_edit->setImage('far:edit blue');
        $action_edit->setField('id');
        //$this->datagrid->setActionSide('right').
        $this->datagrid->addAction($action_edit);
        // create DELETE action
        $action_del = new TDataGridAction(array($this, 'onDelete'));
        $action_del->setButtonClass('btn btn-default');
        $action_del->setLabel(_t('Delete'));
        $action_del->setImage('far:trash-alt red');
        $action_del->setField('id');
        $this->datagrid->addAction($action_del);
        // create RESPOND action
        //$action_resp = new TDataGridAction(array('ResponderFormView', 'onLoadFormRemoto'));
        $action_resp = new TDataGridAction(array($this, 'onLoadResponder'));
        $action_resp->setButtonClass('btn btn-default');
        $action_resp->setLabel('Responder Questionário');
        $action_resp->setImage('fa: fa fa-list green');
        $action_resp->setField('id');
        $this->datagrid->addAction($action_resp);
        
        // creates the datagrid column actions
        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);
        
        $order_titulo = new TAction(array($this, 'onReload'));
        $order_titulo->setParameter('order', 'titulo');
        $column_titulo->setAction($order_titulo);
        
        $order_descricao = new TAction(array($this, 'onReload'));
        $order_descricao->setParameter('order', 'descricao');
        $column_descricao->setAction($order_descricao);
        
        // create the datagrid model
        $this->datagrid->createModel();
        $this->datagrid->disableDefaultClick();
        
        // create the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());
        
        $panel = new TPanelGroup;
        $panel->add($this->datagrid)->style = 'overflow-x:auto';
        $panel->addFooter($this->pageNavigation);        
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);
        $container->add($panel);
        
        parent::add($container);
    }

    /**
     * Formata data do TDataGridColumn
     * @param type $date
     * @param type $object
     * @return type
     */
    public static function formatDate($date, $object)
    {
        $dt = new DateTime($date);
        return $dt->format('d/m/Y');
    }    
    
    /**
     * Função duplicad Questionário
     * 
     * @param array $param
     */
    public static function onClone($param){
        
        try
        {
            TTransaction::open('questionario');
            $id = $param['id'];
            
            $questionario = new Questionarios($id);
            $questionario->cloneQuestionario($id);
            
            TTransaction::close();
            $action = new TAction(['QuestionarioList','onReload']);
            new TMessage('info', TAdiantiCoreTranslator::translate('Record saved'), $action);
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
        
    }
    /**
     * Open an input dialog
     */
    public static function onAtribuir( $param )
    {

        // input fields
        $validade_inicio= new TDateTime('validade_inicio');
        $validade_fim   = new TDateTime('validade_fim');
        $id             = new THidden('id');

        $validade_inicio->setMask('dd/mm/yyyy hh:ii');
        $validade_inicio->setDatabaseMask('yyyy-mm-dd hh:ii'); 
        $validade_fim->setMask('dd/mm/yyyy hh:ii');
        $validade_fim->setDatabaseMask('yyyy-mm-dd hh:ii'); 
        $validade_inicio->setValue(date('d/m/Y H:i'));
        $validade_fim->setValue(date('d/m/Y H:i', strtotime("+30 minutes")));
        $id->setValue($param['id']);

        TTransaction::open('questionario');
        $questionario = new Questionarios($param['id']);
        TTransaction::close();
        $titulo = 'Criar um questionário atribuído';
        $msg = 'Os jogadores devem completar o questionário atribuído até:';
        if( !empty($questionario->data_fim)){
            $titulo = 'Questionário já foi atribuído';
            $msg = 'No momento, este questionário está atribuído a jogadores';
            $validade_inicio->setValue(TDate::date2br($questionario->validade_inicio) );
            $validade_fim->setValue(TDate::date2br($questionario->validade_fim) );
            $validade_inicio->setEditable(FALSE);
            $validade_fim->setEditable(FALSE);
        }

        $form = new BootstrapFormBuilder('input_form');
        $form->addFields( [new TLabel($msg)], );
        $row = $form->addFields( [new TLabel('Validade Inicial')], [$validade_inicio] );
        $row->layout = ['col-sm-3', 'col-sm-4'];
        $row = $form->addFields( [new TLabel('Validade Final')], [$validade_fim] );
        $row->layout = ['col-sm-3', 'col-sm-4'];
        $form->addFields( [$id] ); 

        // form action
        if( empty($questionario->data_fim))
            $form->addAction(_t('Save'), new TAction(array(__CLASS__, 'onConfirmAtribuir')), 'fa:save green');
        $form->addAction(_t('Close'), new TAction(array(__CLASS__, 'onCloseInput')), 'fa:times red');

        // show input dialot
        new TInputDialog($titulo, $form);

    }
    static public function onCloseInput(){}
    
    static public function onConfirmAtribuir($param){
        try
        {
            $validade_inicio = $param['validade_inicio'];
            $validade_fim = $param['validade_fim'];
            $id   = $param['id'];
            if( empty( $validade_inicio ) || empty( $validade_fim ))
                throw new Exception('Campo Validade Inicial/Final deve ser informado.');
            
            $dataInicio = Date(str_replace("/", "-", $validade_inicio) );
            $dataFim = Date(str_replace("/", "-", $validade_fim));
            if( $dataFim < $dataInicio)
                throw new Exception('Data Inicial deve ser igual ou superior a Data Final.');

            TTransaction::open('questionario');
            
            $questionario = new Questionarios($id);
            $questionario->validade_inicio = date( "Y-m-d H:i", strtotime( $dataInicio ));
            $questionario->validade_fim = date( "Y-m-d H:i", strtotime( $dataFim ));
            $questionario->store();        
            
            TTransaction::close();
            $action = new TAction(['QuestionarioList','onReload']);
            new TMessage('info', TAdiantiCoreTranslator::translate('Record saved'), $action);
        }
        catch (Exception $e)
        {
            $action = new TAction(['QuestionarioList','onAtribuir'], ['id' => $id]);
            new TMessage('error', $e->getMessage(), $action);
            TTransaction::rollback();
        }
        
    }
    public function onLoadResponder($param){
        // store data in the session
        TSession::setValue('questionario_id', $param['id']);
        // Load another page
        AdiantiCoreApplication::loadPage('ResponderFormView');

    }
}
