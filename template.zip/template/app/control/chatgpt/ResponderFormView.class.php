<?php
use \Firebase\JWT\JWT;

/**
 * MultiStepMultiForm2View
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class ResponderFormView extends TPage {

    private $form; // form
    private $formFields;

    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct() {
        parent::__construct();

        $ini  = AdiantiApplicationConfig::get();
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Responder');
        $this->form->setFormTitle('Responda ao Questionário');
        $this->form->setColumnClasses(2, ['col-sm-3', 'col-sm-9']);

        // create the form fields
        $jwt          = new TEntry('jwt');
        $questionario = new TEntry('questionario');
        $perguntas    = new THidden('perguntas');
        $questionario->setEditable(FALSE);

        // add the fields
        $this->form->addFields( [$jwt] );
        $this->form->addFields(['Questionário'], [$questionario]);
        $this->form->addFields([], [$perguntas] );
        // add a form action
        $this->form->addAction(_t('Back'), new TAction(array($this, 'onBackForm')), 'fa:chevron-circle-left orange');
        $this->form->addAction(_t('Confirm'), new TAction(array($this, 'onConfirm')), 'far:check-circle green');

        //$this->formFields = [$questionario, $perguntas];
        //$this->form->setFields($this->formFields);

        //$this->onLoad();
        if( TSession::getValue('questionario_id') )
            $this->onLoadFormView();

        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', 'MultiStepMultiFormView'));
        $vbox->add($this->form);

        // add the form to the page
        parent::add($vbox);
    }
    /**
     * Form load
     */
    public function onLoad($param = null)
    {
        if( isset($param['jwt']) ){
            try {
                $loadSession = TSession::getValue('questionario_id');

                TSession::delValue('questionario_id');
                $token   = $this->getToken($param['jwt']);
                $id      = $token['questionario_id'];
                $user_id = $token['user_id'];

                if( $user_id != TSession::getValue('userid') )
                    throw new Exception('Questionário sem permissão para responder.');
                    
                $data = new stdClass;
                $data->jwt = $param['jwt'];
                $this->form->setData($data);
                
                TSession::setValue('questionario_id', $id);
                // close the transaction
                TTransaction::close();
                if( !$loadSession )
                    $this->onLoadFormView();
            }
            catch (Exception $e) // in case of exception
            {
                new TMessage('error', $e->getMessage());
                TTransaction::rollback();
                AdiantiCoreApplication::loadPage('EmptyPage');
            }

        } else if( isset($param['back']) ){
            $btnName = strtolower('btn_'._t('Back'));
            $btn = $this->form->getField($btnName);
            $btn->setAction(new TAction([$this, 'onBackForm'], $param ), _t('Back'));
        }

    }
    /**
     * Lê tokem para responder questionário
     * 
     * @param string $jwt
     * @return array;
     */
    private static function getToken($jwt = null){
        $token = null;
        if( $jwt ){
            
            $ini = AdiantiApplicationConfig::get();            
            $key = APPLICATION_NAME . $ini['general']['seed'];            
            $token = (array) JWT::decode($jwt, $key, array('HS256'));            
        }
        return $token;
    }

    /**
     * load the previous data
     */
    public function onLoadFormView($param = null) {
        try {
            //var_dump($param);
            // open a transaction with database 'permission'
            TTransaction::open('questionario');

            $id = TSession::getValue('questionario_id');
            if( $id == null )
                throw new Exception(_t('Permission denied'));
            
            $questionario = new Questionarios($id);
            //set Data
            $data = new stdClass();
            $data->questionario = $questionario->titulo;
            $this->form->setData($data);

            //Perguntas
            $perguntas = Perguntas::where('questionario_id', '=', $id)->load();
            if( $perguntas ){
                foreach ($perguntas as $i => $pergunta ) {
                    
                    $labelPergunta = "Pergunta ".($i+1).": <b>" . $pergunta->pergunta_texto."</b>";

                    $radio = new TRadioGroup("radio$i");
                    $radio->addValidation( "<b>Pergunta ".($i+1).": {$pergunta->pergunta_texto}</b>", new TRequiredValidator);
                    // add the combo items
                    $items = array();

                    //Alternativas
                    $alternativas = Alternativas::where('pergunta_id', '=', $pergunta->id)->load();
                    if( $alternativas ){
                        foreach ($alternativas as $alternativa ) {
                            $value = $pergunta->id . '_'. $alternativa->id . '_' .
                                    substr( $alternativa->alternativa_texto,0,1);
                            $items[$value] = $alternativa->alternativa_texto;                            
                        }
                    }
                    $radio->addItems($items);

                    $this->form->addContent( ['<hr>'] );

                    $row = $this->form->addFields([new TLabel($labelPergunta)]);
                    $row = $this->form->addFields([$radio]);
                    $resp = new TLabel('olá mundo');
                    $resp->setId("resposta$i");
                    $resp->style = 'color: red;font-weight: bold;display:none;';
                    $row = $this->form->addFields([$resp]);
                }
            }
            // close the transaction
            TTransaction::close();            
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
            //AdiantiCoreApplication::loadPage('WelcomeView');
        }
    }

    /**
     * Load the previous form
     */
    public function onBackForm($param) {
        // Load another page
        $backForm = isset($param['back']) ? $param['back'] : 'QuestionarioList';
        AdiantiCoreApplication::loadPage($backForm);
    }

    /**
     * confirmation screen
     */
    public function onConfirm($param) {
        try {
            $data = $this->form->getData();
            $this->form->validate();
            
            // open a transaction with database 'permission'
            TTransaction::open('questionario');

            $id = TSession::getValue('questionario_id');
            if( $id == null )
                throw new Exception(_t('Permission denied'));
            
            $respostas = Respostas
                            ::where('questionario_id', '=', $id, TExpression::AND_OPERATOR)
                            ->where('user_id', '=', TSession::getValue('userid') )
                            ->load();

            if( $respostas )
                throw new Exception('Questionário já foi respondido em '.TDate::date2br($respostas[0]->data_resposta));
            
            $questionario = new Questionarios($id);
            
            //Perguntas
            $perguntas = Perguntas::where('questionario_id', '=', $id)->load();
            if( $perguntas ){
                $respostaCorreta = 0;
                foreach ($perguntas as $i => $pergunta ) {
                    
                    if( !isset( $data->{"radio$i"} ) )
                        throw new Exception('Formulário Inconsistente.');

                    $radio = explode( "_", $data->{"radio$i"} );
                    $pergunta_id = $radio[0];
                    $alternativa_id = $radio[1];

                    $alternativa = Alternativas
                            ::where('pergunta_id', '=', $pergunta_id, TExpression::AND_OPERATOR)
                            ->where('alternativa_correta', '=', 'S') 
                            ->load();
                    //Grava Resposta
                    $resposta = new Respostas();
                    $resposta->user_id = TSession::getValue('userid');
                    $resposta->questionario_id = $id;
                    $resposta->pergunta_id = $pergunta_id;
                    $resposta->alternativa_respondida_id = $alternativa_id;
                    $resposta->alternativa_correta_id = $alternativa[0]->id;
                    $resposta->store();
                    
                    $resulado = 'Resposta Correta é: '.$alternativa[0]->alternativa_texto;
                    $cor = 'red';
                    if( $alternativa_id == $alternativa[0]->id ){
                        $resulado = 'Reposta Correta!';
                        $cor = 'green';
                        $respostaCorreta++;
                    }
                    TScript::create("$('#resposta".$i."').show();");
                    TScript::create("$('#resposta".$i."').html('<font color=".$cor.">".$resulado."</font>');");
                }
                $calculoAcerto = ($respostaCorreta / ($i+1) * 100 );
                $typeMessage = ($calculoAcerto == 0) ? 'error' : 
                               ($calculoAcerto == 100 ? 'info' : 'warning' );
                new TMessage( $typeMessage, 'Você acertou '.$calculoAcerto.'%' );
                $btnConfirma = 'btn_'. strtolower(_t('Confirm'));
                TButton::disableField('form_Responder', $btnConfirma);
            }
            
            // close the transaction
            TTransaction::close();            
        } catch (Exception $e) {
            new TMessage('error', $e->getMessage());
        }
    }
    public function onClose(){
        var_dump("fechou");
        die("fechou");
        TSession::delValue('questionario_id');
    }
}
