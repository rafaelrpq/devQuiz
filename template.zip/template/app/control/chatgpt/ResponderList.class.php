<?php
/**
 * SystemUserList
 *
 * @version    1.0
 * @package    control
 * @subpackage admin
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class ResponderList extends TStandardList
{
    protected $form;     // registration form
    protected $datagrid; // listing
    protected $pageNavigation;
    protected $formgrid;
    protected $deleteButton;
    protected $transformCallback;
    
    /**
     * Page constructor
     */
    public function __construct()
    {
        parent::__construct();
        parent::setDatabase('questionario');            // defines the database
        parent::setActiveRecord('Questionarios');   // defines the active record
        parent::setDefaultOrder('id', 'asc');         // defines the default order
        parent::addFilterField('id', '=', 'id'); // filterField, operator, formField
        parent::addFilterField('user_id', '=', TSession::getValue('userid') ); // filterField, operator, formField
        parent::addFilterField('titulo', 'like', 'titulo'); // filterField, operator, formField


        //Filtra por usuário logado
        $criteria = new TCriteria;
        //$criteria->add(new TFilter('user_id', '=', TSession::getValue('userid')));            
        $criteria->add(new TFilter('validade_fim', '>=', date('Y-m-d H:i') ));
        $criteria->add(new TFilter('id', 'in', 
                "(SELECT distinct questionario_id FROM compartilhamentos WHERE user_email = '".TSession::getValue('usermail')."')"));

        $this->setCriteria($criteria);

        // creates the form
        $this->form = new BootstrapFormBuilder('form_search_SystemUser');
        $this->form->setFormTitle('Questionários');       

        // create the form fields
        $id = new TEntry('id');
        $titulo = new TEntry('titulo');
        $descricao = new TEntry('descricao');
        
        // add the fields
        $this->form->addFields( [new TLabel('Id')], [$id] );
        $this->form->addFields( [new TLabel('Título')], [$titulo] );
        $this->form->addFields( [new TLabel('Descrição')], [$descricao] );
        
        $id->setSize('30%');
        $titulo->setSize('70%');
        $descricao->setSize('70%');
        
        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue('SystemUser_filter_data') );
        
        // add the search form actions
        $btn = $this->form->addAction(_t('Find'), new TAction(array($this, 'onSearch')), 'fa:search');
        $btn->class = 'btn btn-sm btn-primary';
        
        // creates a DataGrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        //$this->datagrid->datatable = 'true';
        $this->datagrid->style = 'width: 100%';
        //$this->datagrid->setHeight(420);
        $this->datagrid->datatable ='true';

        
        $button = new TActionLink('', new TAction([$this, 'onReload']), 'green', null, null, 'fa:plus-circle');
        $button->class = 'btn btn-default inline-button';
        $button->title = _t('New');
        
        // creates the datagrid columns
        $column_id = new TDataGridColumn('id', 'Id', 'center', 50);
        $column_titulo = new TDataGridColumn('titulo', 'Título', 'left');
        $column_descricao = new TDataGridColumn('descricao', 'Descrição', 'left');
        $column_criacao = new TDataGridColumn('data_criacao', 'Data Criação', 'left');
        $column_criacao->setTransformer(array($this, 'formatDate'));
        
        $column_titulo->enableAutoHide(500);
        $column_descricao->enableAutoHide(500);
        // add the columns to the DataGrid
        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_titulo);
        $this->datagrid->addColumn($column_descricao);
        $this->datagrid->addColumn($column_criacao);

        // create RESPOND action
        //$action_resp = new TDataGridAction(array('ResponderFormView', 'onLoadFormRemoto'));
        $action_resp = new TDataGridAction(array($this, 'onLoadResponder'));
        $action_resp->setButtonClass('btn btn-default');
        $action_resp->setLabel('Responder Questionário');
        $action_resp->setImage('fa: fa fa-list green');
        $action_resp->setField('id');
        $this->datagrid->addAction($action_resp);
        
        // creates the datagrid column actions
        $order_id = new TAction(array($this, 'onReload'));
        $order_id->setParameter('order', 'id');
        $column_id->setAction($order_id);
        
        $order_titulo = new TAction(array($this, 'onReload'));
        $order_titulo->setParameter('order', 'titulo');
        $column_titulo->setAction($order_titulo);
        
        $order_descricao = new TAction(array($this, 'onReload'));
        $order_descricao->setParameter('order', 'descricao');
        $column_descricao->setAction($order_descricao);
        
        // create the datagrid model
        $this->datagrid->createModel();
        $this->datagrid->disableDefaultClick();
        
        // create the page navigation
        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());
        
        $panel = new TPanelGroup;
        $panel->add($this->datagrid)->style = 'overflow-x:auto';
        $panel->addFooter($this->pageNavigation);        
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);
        $container->add($panel);
        
        parent::add($container);
    }

    /**
     * Formata data do TDataGridColumn
     * @param type $date
     * @param type $object
     * @return type
     */
    public static function formatDate($date, $object)
    {
        $dt = new DateTime($date);
        return $dt->format('d/m/Y');
    }    
    

    public function onLoadResponder($param){
        // store data in the session
        TSession::setValue('questionario_id', $param['id']);
        // Load another page
        AdiantiCoreApplication::loadPage('ResponderFormView', 'onLoad', ['back'=>'ResponderList']);

    }
}
