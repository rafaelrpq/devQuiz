<?php
/**
 * SaleForm Registration
 * @author  <your name here>
 */
class SaleForm extends TPage
{
    protected $form; // form
    
    /**
     * Class constructor
     * Creates the page and the registration form
     */
    function __construct()
    {
        parent::__construct();
        $this->setTargetContainer('adianti_right_panel');
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Pergunta');
        $this->form->setFormTitle('Pergunta');
        $this->form->setProperty('style', 'margin:0;border:0');
        $this->form->setClientValidation(true);
        
        // master fields
        $id               = new TEntry('id');
        $questionario_id  = new THidden('questionario_id');
        $pergunta_texto   = new TEntry('pergunta_texto');
        $tipo_alternativa = new TCombo('tipo_alternativa');
        $tipo_alternativa->addItems(array( 'Opcao'=>'Opção', 'Texto'=>'Texto', 'MultiplaEscolha'=>'Múltipla Escolha' ) );
        
        // detail fields
        $alternativa_detail_unqid          = new THidden('uniqid');
        $alternativa_detail_pergunta_id    = new THidden('pergunta_id');
        $alternativa_detail_alternativa_id = new TEntry('alternativa_id');
        $alternativa_detail_alternativa    = new TEntry('alternativa_texto');
        $alternativa_detail_correta        = new TCombo('alternativa_correta'); 
        
        // adjust field properties
        $id->setEditable(false);
        $alternativa_detail_correta->addItems(array( 'S'=>'Sim', 'N'=>'Nao' ) );
        $alternativa_detail_correta->setValue('S');
        
        // add validations
        
        // change action
        //$product_detail_product_id->setChangeAction(new TAction([$this,'onProductChange']));
        
        // add master form fields
        $this->form->addFields( [$questionario_id] );
        $this->form->addFields( [new TLabel('ID')], [$id] );
        $this->form->addFields( [new TLabel('Pergunta')], [$pergunta_texto] );
        $this->form->addFields( [new TLabel('Tipo Alternativa')], [$tipo_alternativa] );        
        
        //details
        $this->form->addContent( ['<h4>Details</h4><hr>'] );
        $this->form->addFields( [$alternativa_detail_unqid], [$alternativa_detail_pergunta_id] );
        //$this->form->addFields( [ new TLabel('ID', '#FF0000') ], [$alternativa_detail_alternativa_id] );
        $this->form->addFields( [ new TLabel('Alternativa', '#FF0000') ],   [$alternativa_detail_alternativa] );
        $this->form->addFields( [ new TLabel('Correta', '#FF0000') ],   [$alternativa_detail_correta] );
        
        $add_product = TButton::create('add_product', [$this, 'onProductAdd'], 'Register', 'fa:plus-circle green');
        $add_product->getAction()->setParameter('static','1');
        $this->form->addFields( [], [$add_product] );
        
        $this->product_list = new BootstrapDatagridWrapper(new TDataGrid);
        $this->product_list->setHeight(150);
        $this->product_list->makeScrollable();
        $this->product_list->setId('products_list');
        $this->product_list->generateHiddenFields();
        $this->product_list->style = "min-width: 700px; width:100%;margin-bottom: 10px";
        //$this->product_list->setMutationAction(new TAction([$this, 'onMutationAction']));
        
        $col_uniq     = new TDataGridColumn( 'uniqid', 'Uniqid', 'center', '10%');
        $col_id       = new TDataGridColumn( 'id', 'ID', 'center', '10%');
        $col_qid      = new TDataGridColumn( 'questionario_id', 'QuestionarioID', 'center', '10%');
        $col_pid      = new TDataGridColumn( 'pergunta_id', 'Pergunta ID', 'center', '10%');
        $col_alternativa = new TDataGridColumn( 'alternativa_texto', 'Alternativa', 'left', '40%');
        $col_correta  = new TDataGridColumn( 'alternativa_correta', 'Correta', 'left', '40%');
        
        $this->product_list->addColumn( $col_uniq );
        $this->product_list->addColumn( $col_id );
        $this->product_list->addColumn( $col_qid );
        $this->product_list->addColumn( $col_pid );
        $this->product_list->addColumn( $col_alternativa );
        $this->product_list->addColumn( $col_correta );        
        
        $col_id->setVisibility(false);
        $col_uniq->setVisibility(false);
        $col_qid->setVisibility(false);
        $col_pid->setVisibility(false);
        
        // creates two datagrid actions
        $action1 = new TDataGridAction([$this, 'onEditItemProduto'] );
        $action1->setFields( ['uniqid', '*'] );
        
        $action2 = new TDataGridAction([$this, 'onDeleteItem']);
        $action2->setField('uniqid');
        
        // add the actions to the datagrid
        $this->product_list->addAction($action1, _t('Edit'), 'far:edit blue');
        $this->product_list->addAction($action2, _t('Delete'), 'far:trash-alt red');
        
        $this->product_list->createModel();
        
        $panel = new TPanelGroup;
        $panel->add($this->product_list);
        $panel->getBody()->style = 'overflow-x:auto';
        $this->form->addContent( [$panel] );
        
        //$this->form->addHeaderActionLink( _t('Close'),  new TAction([__CLASS__, 'onClose'], ['static'=>'1']), 'fa:times red');
        $this->form->addHeaderActionLink( _t('Close'),  new TAction(['PerguntaList', 'onReload'], ['id'=> TSession::getValue('questionario_id') ]), 'fa:times red');
        $this->form->addAction( 'Save',  new TAction([$this, 'onSave'], ['static'=>'1']), 'fa:save green');
        $this->form->addAction( 'Clear', new TAction([$this, 'onClear']), 'fa:eraser red');
        
        // create the page container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->add($this->form);
        parent::add($container);
    }
    
    /**
     * Pre load some data
     */
    public function onLoad($param)
    {
        $data = new stdClass;
        $data->customer_id   = $param['customer_id'];
        $this->form->setData($data);
    }
    
    
    /**
     * On product change
     */
    public static function onProductChange( $params )
    {
        if( !empty($params['product_detail_product_id']) )
        {
            try
            {
                TTransaction::open('samples');
                $product   = new Product($params['product_detail_product_id']);
                TForm::sendData('form_Pergunta', (object) ['product_detail_price' => $product->sale_price ]);
                TTransaction::close();
            }
            catch (Exception $e)
            {
                new TMessage('error', $e->getMessage());
                TTransaction::rollback();
            }
        }
    }
    
    
    /**
     * Clear form
     * @param $param URL parameters
     */
    function onClear($param)
    {
        $this->form->clear();
        $object = new stdClass();
        $object->questionario_id = TSession::getValue('questionario_id');
        $this->form->setData($object);        
    }
    
    /**
     * Add a product into item list
     * @param $param URL parameters
     */
    public function onProductAdd( $param )
    {
        try
        {
            $this->form->validate();
            $data = $this->form->getData();

            if( (! $data->alternativa_texto) || (! $data->alternativa_correta) )
            {
                throw new Exception('The fields Alternativa and Correta are required');
            }
            
            $uniqid = !empty($data->uniqid) ? $data->uniqid : uniqid();
            
            $grid_data = ['uniqid'      => $uniqid,
                          'pergunta_id'      => $data->pergunta_id,
                          'alternativa_texto'   => $data->alternativa_texto,
                          'alternativa_correta' => $data->alternativa_correta ];
            
            // insert row dynamically
            $row = $this->product_list->addItem( (object) $grid_data );
            $row->id = $uniqid;

            TDataGrid::replaceRowById('products_list', $uniqid, $row);
            
            // clear product form fields after add
            $data->uniqid = '';
            $data->alternativa_id = '';
            $data->alternativa_texto = '';
            $data->alternativa_correta = '';
            
            // send data, do not fire change/exit events
            TForm::sendData( 'form_Pergunta', $data, false, false );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());
            new TMessage('error', $e->getMessage());
        }
    }
    
    /**
     * Edit a product from item list
     * @param $param URL parameters
     */
    public static function onEditItemProduto( $param )
    {
        $data = new stdClass;
        $data->uniqid           = $param['uniqid'];
        //$data->id               = $param['id'];
        $data->pergunta_id      = $param['pergunta_id'];
        $data->alternativa_texto   = $param['alternativa_texto'];
        $data->alternativa_correta = $param['alternativa_correta'];
        
        // send data, do not fire change/exit events
        TForm::sendData( 'form_Pergunta', $data, false, false );
    }
    
    /**
     * Delete a product from item list
     * @param $param URL parameters
     */
    public static function onDeleteItem( $param )
    {
        $data = new stdClass;
        $data->uniqid = '';
        $data->pergunta_id = '';
        $data->alternativa_id = '';
        $data->alternativa_texto = '';
        $data->alternativa_correta = '';

        // send data, do not fire change/exit events
        TForm::sendData( 'form_Pergunta', $data, false, false );

        // remove row
        TDataGrid::removeRowById('products_list', $param['uniqid']);
    }
    
    /**
     * Edit Sale
     */
    public function onEdit($param)
    {
        try
        {
            TTransaction::open('questionario');
            
            if (isset($param['key']))
            {
                $key = $param['key'];
                
                $object = new Perguntas($key);
                $alternativa_items = Alternativas::where('pergunta_id', '=', $object->id)->load();
                
                foreach( $alternativa_items as $item )
                {
                    $item->uniqid = uniqid();
                    $row = $this->product_list->addItem( $item );
                    $row->id = $item->uniqid;
                }
                $this->form->setData($object);
                TTransaction::close();
            }
            else
            {
                $this->form->clear();
                $object = new stdClass();
                $object->questionario_id = TSession::getValue('questionario_id');
                $this->form->setData($object);
            }
        }
        catch (Exception $e)
        {
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }
    
    /**
     * Save the sale and the sale items
     */
    public function onSave($param)
    {
        try
        {
            TTransaction::open('questionario');
            
            $data = $this->form->getData();
            $this->form->validate();
            
            $pergunta = new Perguntas;
            $pergunta->fromArray((array) $data);
            $pergunta->store();
            
            Alternativas::where('pergunta_id', '=', $pergunta->id)->delete();

            if( !empty($param['products_list_pergunta_id'] ))
            {
                foreach( $param['products_list_pergunta_id'] as $key => $item_id )
                {
                    $item = new Alternativas;
                    $item->questionario_id  = $pergunta->questionario_id;
                    $item->pergunta_id  = $pergunta->id;
                    $item->alternativa_texto  = $param['products_list_alternativa_texto'][$key];
                    $item->alternativa_correta = $param['products_list_alternativa_correta'][$key];
                    
                    $item->store();
                }
            }
            
            TForm::sendData('form_Pergunta', (object) ['id' => $pergunta->id]);
            
            TTransaction::close(); // close the transaction
            new TMessage('info', TAdiantiCoreTranslator::translate('Record saved'));
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage());
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback();
        }
    }
    
    /**
     *
     */
    public static function onMutationAction($param)
    {
        // Form data: $param['form_data']
        // List data: $param['list_data']
        //echo '<pre>';var_dump($param);
        $total = 0;
        
        if ($param['list_data'])
        {
            foreach ($param['list_data'] as $row)
            {
                $total += ( floatval($row['sale_price']) - floatval($row['discount'])) *  floatval($row['amount']);
            }
        }
        
        TToast::show('info', 'Novo total: <b>' . 'R$ '.number_format($total, 2, ',', '.') . '</b>', 'bottom right');
    }
    
    /**
     * Closes window
     */
    public static function onClose()
    {
        TScript::create("Template.closeRightPanel()");
    }
}
